﻿This folder contains all the images used by the SP Module.
These will be the icons for webs, document libraries and lists.